# Table

Tables of runs, results and facts: 14px text, cells 10 × 14, `hairline` rules between rows and none between columns.

- Headers in `ink` 600 on a ground a third of the way to `vellum-deep`; cells in `ink-muted`.
- Numbers right-aligned with tabular lining figures; units in the header or after the number with a space (*25 M*).
- A numbered caption below (*Table 1.*), in `caption`.
- The consumer provides the rows and the caption. On a phone the table scrolls sideways inside its container rather than wrapping cells.
