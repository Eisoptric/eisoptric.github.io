# Chart

A figure in a research note: series in `chart-1` onward, gridlines in `hairline`, ticks and axis title in `ink-muted`, a numbered caption below.

- The consumer provides the data, the series names, the axis title and the caption sentence.
- Assign `chart-1`…`chart-6` in order; the smallest Shoggoth takes `chart-1` and keeps it across the piece. A seventh series folds into Other.
- 2px lines, 8px+ markers with a 2px ground ring, a legend above the plot and the series name at each line's end (up to four series). Every marker carries a tooltip with model, step and value.
- One y-axis. Training steps on a log x-axis when early steps matter. Text is never set in a series colour.
