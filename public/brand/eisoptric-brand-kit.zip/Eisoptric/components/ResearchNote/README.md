# ResearchNote

The layout of every published note: the main line's primary output.

- Top: a `label` (NOTEBOOK · NO. n · the model), the title in `title`, a one-sentence `lede` in `ink-muted`, then a 64px `gilt` rule.
- Body in `body` at a 38rem measure; sections numbered with a vermilion § and arabic numerals, starting at 1. The question first, then what we observe, then the tools used.
- Figures use Chart or Heatmap, full measure, with *Fig. n.* captions; tables use Table.
- References last, in `caption`, author and year in the text as a `lapis` link.
- The consumer provides the text, figures and references. A Chinese note uses the 中文 styles and the same structure.
