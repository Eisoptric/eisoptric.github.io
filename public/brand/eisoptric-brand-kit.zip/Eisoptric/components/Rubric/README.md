# Rubric

The section heading with a vermilion section sign, and the drop capital that opens a piece: the two places a page spends its vermilion.

- Heading: `heading` style in `ink`; a `vermilion` § followed by the section number and a full stop (*§ 2. Superposition*). Mark the § `aria-hidden` so screen readers read "2. Superposition".
- Drop capital: the first letter of a piece's first paragraph only, in `display` family 600, `vermilion`, three lines of `body` tall.
- At most three vermilion touches per view, the lozenge included. A page of many sections keeps the § and drops the drop capital.
- The consumer provides the text and the section number; sections are numbered in arabic numerals from 1.
