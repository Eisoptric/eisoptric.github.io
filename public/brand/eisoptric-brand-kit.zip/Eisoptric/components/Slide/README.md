# Slide

A talk slide: Nocturne, 16:9, 64px margins.

- Set `data-theme="nocturne"` on the slide so every token takes its Nocturne value.
- One claim per slide as a `title` sentence with a full stop; the evidence below it, a figure or one `body` sentence in `ink-muted`; a `label` above naming the model and note.
- The glyph at 32px in the bottom-right corner and the page number bottom-left. Never the full mark, never a lockup, except on the title slide.
- The consumer provides the claim, the figure and the number.
