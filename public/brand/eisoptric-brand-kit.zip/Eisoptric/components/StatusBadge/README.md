# StatusBadge

A one-word state on a fact, a feature or an issue: *Current*, *Planned*, *Fixed*, *Open*.

- Uppercase EB Garamond 500 at 12px, 0.12em, on `vellum-deep` with a `hairline` edge and `radius-sm`.
- *Current* in `ink`, *Planned* in `lapis`, *Fixed* in `verdigris-ink`, *Open* in `vermilion` (one of the view's rubric touches). Every pair is 4.5:1 or more in both themes.
- The word is the meaning; the colour only helps. Never a coloured dot or an empty badge. On Chinese pages the words are 現況、規劃中、已修正、未解決 at 0.06em.
- The consumer provides the state; there are no other states.
