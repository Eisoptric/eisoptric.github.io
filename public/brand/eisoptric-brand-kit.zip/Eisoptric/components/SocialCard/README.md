# SocialCard

The Open Graph image for every page and post, 1200 × 630, matching the site's `og.png`.

- `vellum` ground, 96px margins. A `label` at 20px, the title in Cormorant 500 at 120px (the name, or a note's short title), one italic line at 36px in `ink-muted`, a 64 × 2 `gilt` rule, the address.
- The full mark at 320px, centred on the right. No photograph, no gradient.
- A note's card replaces the title and the italic line; everything else stays. The consumer provides those two strings and renders the card to PNG.
