# Epigraph

A short Greek or Latin line that opens a long piece, always followed by its translation and source.

- The line: Cormorant Garamond italic 500 at 28/34 in `ink`, with `lang` set (`grc`, `la`).
- A 64px `gilt` rule (`space-16` long, 1px), then the translation and source in `caption`, `ink-muted`.
- One per piece, only at the start, only where the line bears on the argument. This counts as the view's one ornament: no ring or rubric run beside it.
- The consumer provides the original, the translation and the source.
