# NavChip

The header's navigation links: the one shape besides circles allowed `radius-full`.

- 40px tall, padding 0 18, a `hairline` edge on a ground halfway between `vellum` and `vellum-deep`, EB Garamond 500 at 16px in `ink`.
- The current page sets `aria-current="page"`: `vellum-deep` ground and an `ink-muted` edge. The `hairline` edge alone is decorative; the chip's label and ground carry it.
- Navigation only. Content, tags and filters never sit in pills; they use a status badge or plain text.
- The consumer provides the links and marks the current one.
