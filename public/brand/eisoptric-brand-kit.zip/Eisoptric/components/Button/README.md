# Button

The site's action: square-cut (`radius-sm`), Cormorant Garamond 500 at 17px, 44px tall.

- Primary: `lapis` fill, `on-lapis` text, `ink` on hover. One per view.
- Secondary: 1px `ink` outline on the ground, `vellum-deep` on hover.
- Text link: Cormorant italic 500 at 19px in `lapis`, underlined on hover. Use it for a standalone "read more"; links inside running text stay in `body` and `lapis`.
- Focus: 2px solid `lapis`, 2px offset. The consumer provides the label and the target; labels are verbs or the destination's name, never "Click here".
