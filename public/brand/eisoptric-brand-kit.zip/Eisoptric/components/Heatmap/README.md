# Heatmap

Grids of values: `seq-1`…`seq-5` for magnitude (attention, density), `div-neg-2`…`div-pos-2` for signed values (activations, probe weights, logit differences).

- The consumer provides the matrix, the bin edges and the caption. Bin into the five steps; never interpolate new colours between them.
- Every grid carries its scale beside it, with the end values written out.
- Cells get a 0.5px `hairline` edge, because `seq-1`, `seq-2` and `div-0` sit close to the ground. Each cell has a tooltip with its row, column and exact value.
- Diverging always means vermilion below zero and lapis above, with `div-0` exactly at zero.
