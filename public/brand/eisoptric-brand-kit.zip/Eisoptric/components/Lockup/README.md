# Lockup

The Speculum set with the EISOPTRIC wordmark: horizontal for page headers, stacked for title pages and covers.

- Prefer the outlined files `eisoptric-lockup-horizontal-*.svg` and `eisoptric-lockup-stacked-*.svg` from Logos: they cannot fall back to another face.
- Built live (as in the preview), the consumer provides the Google Fonts link for Cormorant Garamond 500 and draws the mark inline with classes bound to `ink`, `lapis`, `gilt` and `vermilion`, so it follows Vellum and Nocturne.
- Horizontal: the wordmark's cap height equals the mark's E (mark size × 112/256); Cormorant's cap height is 0.625em, so font-size = mark size × 0.7. Gap = mark size × 0.31 (20 at 64). Tracking 0.14em.
- Stacked: tracking 0.22em (compensate the trailing track with an equal negative right margin so it centres), `space-8` between mark and name. An optional `label` line goes below in `ink-muted`.
- Below 64px use the header cut of the mark (ring stroke 8, axis 4, lozenge 24; see the size table in the README), as the site header does at 42px. The glyph stands alone and never goes into a lockup. Never set the wordmark without the mark at sizes under 24px; never put a gilt rule under the name (it competes with the ring).
