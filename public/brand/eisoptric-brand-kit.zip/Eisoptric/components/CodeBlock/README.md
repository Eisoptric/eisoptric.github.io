# CodeBlock

Code, plain-text equations and tensor shapes in IBM Plex Mono.

- Block: 13.5/23 on `vellum-deep`, square-cut, padded 24, scrolling sideways rather than wrapping.
- Syntax colour is kept to two quiet roles: comments in `ink-muted`, keywords and strings in `lapis`. Everything else stays `ink`. No other hues.
- Inline: 0.875em on `vellum-deep` with 1 × 4 padding.
- The consumer provides the code, already escaped.
