# ModelCard

The facts of one Shoggoth checkpoint, as a definition list.

- A `label`, the model name in `title` with its status badge, then the step in `caption`.
- Rows open under a `gilt` rule and are separated by `hairline`: parameters, tokens seen, data order and seed, context length, the code commit, and what was measured. Values in `ink` with tabular figures; no adjectives and no claims.
- Yog-Sothoth never gets a card.
- The consumer provides every value; a value not yet known is written *Not yet measured*, never left blank.
