*Γνῶθι σεαυτόν: know thyself.* Eisoptric is an independent research programme on how language models learn and what goes on inside them: pretraining and interpretability.

The name comes from the Greek *eisoptron* (εἴσοπτρον), a mirror, from *eis* (into) and *opt-* (to see): **looking into**. The identity borrows from two old crafts of looking closely, the illuminated manuscript and the star atlas.

## The main line

We train small models, the **Shoggoth** series, from scratch, and study them until we can say how they learn and what they compute. The aim is to carry that understanding up to frontier scale: one day to train, and to understand, a **Yog-Sothoth**. Everything else Eisoptric releases, Eisoptric Workbench and Eisoptric MCP included, is a by-product of that road: a tool we built for our own work.

Every page, deck and post should be traceable to this line. If a piece cannot say how it serves the Shoggoth work, it does not carry the Eisoptric name.

### Names

| Name | What it is | How to write it |
| --- | --- | --- |
| **Eisoptric** | The research programme. | Title case in text; `EISOPTRIC` only in the wordmark and labels. |
| **Shoggoth** (修格斯) | Our small models, trained and studied in the open. | A codename: no "Eisoptric" in front. Title case; a model is *Shoggoth* plus its size or version, never a new name. |
| **Yog-Sothoth** (猶格索托斯) | The frontier model the work aims at. | A direction, not a product. Name it at most once in a piece, never as a claim of capability, and never on a home page or a cover. |
| **Eisoptric Workbench**, **Eisoptric MCP** | Tools we built for ourselves and released. | Always with the Eisoptric prefix. Describe them by the research need they came from, after the research, never before it. |

The names come from H. P. Lovecraft. A shoggoth is a made thing with no fixed shape that learns by imitation, and no one knows what it thinks: the reason interpretability exists. In the stories Yog-Sothoth is the gate, and the key and guardian of the gate: what lies past the frontier. We borrow the images, not the horror: no tentacles, eyes or eldritch ornament in the visual system, and no long quotations from the stories. The notebook stays a scholar's notebook; the strangeness is in what is being studied.

## The mark: the Speculum

A capital **E** in `ink` faces its own reflection in `lapis` across a `gilt` mirror axis, inside one `gilt` ring. Above the axis a `vermilion` lozenge marks the observer.

The mark has three roles and gives each one pigment:

| Part | Pigment | Meaning |
| --- | --- | --- |
| The two Es | `ink`, `lapis` | The subject: the model, and the model seen from inside. Same letterform, different pigment, never a different shape. |
| Ring and axis | `gilt` | The instrument: a bronze *speculum*, and the mirror plane between what a model does and what we can read of it. |
| Lozenge | `vermilion` | The observer: the point we look from. |

Construction (256-unit canvas, 4-unit grid, generated from one script so every file agrees):
- The E is a single path. Cap height 112, stem 16, arms 8 (2:1 contrast). Each terminal is a serif joined to its arm by a 45° bracket: the top and middle serifs are 6 wide, the foot 8, because it carries the letter's weight. The arms reach 32, 24 and 36 units out from the stem.
- The reflection is the same path under x → 256 − x. Each E stands 4.5 units clear of the axis.
- Ring: radius 116, stroke 4. Axis: 3 wide, 128 long, centred on the E. Lozenge: 20 × 20, 6 units above the axis.

### Which file at which size

| Size on screen | File | Why |
| --- | --- | --- |
| 64px and up | `eisoptric-mark-{vellum,nocturne}.svg` | The full mark, transparent. |
| 32–48px, beside the wordmark | The header cut, drawn inline (no file) | The full mark with the ring at stroke 8, the axis 4 wide and the lozenge 24, so the ring stays a line. The site header uses it at 42px. |
| 20–64px, standing alone | `eisoptric-glyph-{vellum,nocturne}.svg` | No ring; stem 24, arms 16. The ring is the first thing to blur. |
| 16 and 32px | `eisoptric-favicon-{vellum,nocturne}.svg` (+ PNG) | Redrawn on a 32-pixel grid so every stroke lands on whole pixels. |
| Avatars, app icons, social | `eisoptric-icon-{vellum,nocturne}.svg` (+ 512, 180 PNG) | Square, full-bleed ground; the 256 canvas scaled to 440 and centred, 36 on each side, so the ring spans 79% of the tile. Safe for a circular crop. |
| Headers | `eisoptric-lockup-horizontal-*.svg` | Mark beside the wordmark. |
| Title pages | `eisoptric-lockup-stacked-*.svg` | Mark over the wordmark. |

Use the `-vellum` file on light grounds and the `-nocturne` file on dark ones; never put a vellum file on a dark ground.

### Rules
- Clear space on every side: a quarter of the mark's width (`space-8` at 128px).
- Never colour the two Es alike, swap their sides (ink is always on the left), rotate or skew the mark, or draw a second ring.
- Never add the old gilt dot under the axis, a drop shadow, or a gradient.
- On a photograph or a busy ground, use the icon file so the mark keeps its own ground.

## The wordmark

`EISOPTRIC` in Cormorant Garamond Medium, uppercase, outlined in the lockup files so it never falls back to another face.
- Horizontal: tracking 0.14em; the wordmark's cap height equals the height of the E in the mark beside it, so the two Es rhyme. Gap between mark and name: 40 at a 128 mark.
- Stacked: tracking 0.22em; the name sits `space-8` below the mark.
- On a phone (under 520px) the header lockup may tighten to a 32px mark, an 8px gap and a 19px wordmark at 0.1em tracking, so the bar keeps its controls on screen. That is the only exception to the proportions.
- In running text write *Eisoptric* in title case; the uppercase form belongs to the wordmark and to labels.

## Colour: pigments, not swatches

Every colour is named for a historical pigment and used the way a scribe used it.

| Token | Role |
| --- | --- |
| `vellum` / `vellum-deep` | The page (`#faf8f4`, a pale warm off-white) and its raised panels. Never pure white. |
| `ink` | Text and the left E. |
| `ink-muted` | Captions, metadata, labels. |
| `lapis` | The brand colour: links, the reflected E, the one primary action, the focus ring. Text on a lapis fill is `on-lapis`. |
| `vermilion` | The observer. The lozenge, the section sign §, a drop capital. At most three touches a view; never a fill or a button. |
| `gilt` | The instrument. The ring, the axis, rules and ornaments. A graphic colour only, never text. |
| `gilt-ink` | Gilt for text, when a word must read as gold. Darker than `gilt` in Vellum (5.0:1 / 4.6:1); never used in the mark or for rules. |
| `verdigris-ink` | Copper green for the one status that means done: a *Fixed* badge. Always with the word. |
| `hairline` | Quiet table rules and chart gridlines. Decorative only, never the sole border of a control. |

Two themes: **Vellum** (the manuscript; the default) and **Nocturne** (the star atlas; dark mode and slides). Every text token holds 4.5:1 on `vellum` and `vellum-deep` in both themes; the figures are in each token's note.

Focus: a 2px solid `lapis` outline with a 2px offset, on every interactive element.

## Charts and figures

Figures are where the research is read, so they follow the same rules as the page.

- Colour does one job per chart. **Identity** (which model, which run): `chart-1` to `chart-6`, assigned in that order and never cycled. **Magnitude** (attention, density): `seq-1` to `seq-5`, one hue. **Sign** (activations, logit differences): `div-neg-2` to `div-pos-2`, vermilion below zero, lapis above, a grey with no hue at zero.
- Series colours are pigments stepped for charts, not the text pigments: `chart-1` is lapis, `chart-2` vermilion, but lighter or darker so every slot holds 3:1 as a mark. The vermilion rubric rule does not count chart marks.
- When Shoggoth sizes are compared, the smallest model always takes `chart-1`, the next `chart-2`, and so on; a model keeps its colour across every figure in a piece, even when a filter hides the others.
- More than six series fold into *Other*, or split into small multiples. Scatter plots and small multiples use `chart-1` to `chart-3` only.
- Marks are thin: 2px lines, markers at least 8px, a 2px ground-coloured gap between touching fills. Gridlines in `hairline`, axis labels and ticks in `ink-muted` `caption`, values in `ink`. Text never takes a series colour.
- Two series or more carry a legend; up to four are also labelled at the line's end. One axis per chart, never two y-scales: two measures become two charts.
- Every figure has a number and a caption below it: *Fig. 3.* in `caption`, then one sentence saying what to look at.
- Checkpoints are the x-axis of most figures: label it *Training step* and use a log scale when early steps matter.

## Interface

The site's controls follow the manuscript: square-cut, quiet, one primary action per view.
- **Button**: Cormorant Garamond 500 at 17px, 0.02em, height 44, padding 0 20, `radius-sm`. Primary is `lapis` with `on-lapis` text and turns `ink` on hover; secondary is outlined in `ink` on the ground.
- **Text link**: `lapis`; standalone links set in Cormorant italic 500 at 19px.
- **Navigation chip**: the one shape besides circles that takes `radius-full`: a 40px pill, `hairline` border, a ground halfway to `vellum-deep`, EB Garamond 500 at 16px; the current page darkens its border to `ink-muted`. Content never sits in a pill.
- **Table**: 14px text, cells padded 10 × 14, `hairline` row rules and no verticals, headers in `ink` 600, cells in `ink-muted`.
- **Code block**: IBM Plex Mono 13.5/23 on `vellum-deep`, square-cut, padded 24; in Nocturne the same on Nocturne's `vellum-deep`.
- **Status badge**: the word in uppercase EB Garamond 500, 12px, 0.12em, on `vellum-deep` with a `hairline` edge and `radius-sm`. *Current* in `ink`, *Planned* in `lapis`, *Fixed* in `verdigris-ink`, *Open* in `vermilion` (which counts as one of the view's rubric touches).

## Type

- **Cormorant Garamond** (`display`, `title`, `heading`): the name, titles, headings. 500, or 600 for headings.
- **EB Garamond** (`body`, `caption`, `label`): running text; italic for captions, marginalia and translations.
- **IBM Plex Mono** (`code`): code and tensor shapes. The one modern voice, kept small.

All three are on Google Fonts; the consumer links them. Labels are uppercase at 0.18em tracking, like a frieze inscription.

The scale follows the site: `display` 88 (46 on a phone), `title` 54, `heading` 26, `lede` 20, `body` 17/28, `caption` 14, `label` 13.

### 中文

- 中文用 **Noto Serif TC**，接在拉丁字體之後（`"EB Garamond", "Noto Serif TC"`），讓英文和數字仍由 Garamond 排，漢字由思源宋體排。
- 樣式：`title-zh` 48/62、`heading-zh` 21、`body-zh` 17/31（行高 1.85）、`label-zh` 13（字距 0.2em）。中文標題用 500，不用 600；字距 0.02em。
- 中英、中數之間加半形空格：*訓練 4,000 步*、*Shoggoth 模型*。標點用全形，引號用「」『』，刪節號用……。數字一律阿拉伯數字，§ 編號照英文：*§ 2. 疊加*。
- 中文不用斜體。英文裡用斜體的地方（圖說、旁註、譯文），中文改用 `ink-muted` 正體；書名、篇名用《》〈〉。
- 語氣同一套：先證據後結論，說「我們觀察到」，不說「我們發現了」；能寫數字就不寫形容詞。

## Voice

Write like a careful scholar's notebook: precise, plain and quietly literary.
- Number sections with a vermilion §: *§ 2. Superposition*.
- Give the evidence before the claim. Prefer *we observe* to *we discovered*; prefer a number to an adjective.
- A Greek or Latin epigraph may open a long piece, always with its translation in `caption`.
- Order every piece the same way as the main line: the question about the model first, then what we found, then the tool that made it possible.

Examples:
- Title: *On the Residual Stream as a Shared Workspace*
- Label: `NOTEBOOK · NO. 07`
- Label: `SHOGGOTH · CHECKPOINT 4,000`
- Tagline: *Looking into the minds we train.*

## Icons, images and motion

- **Icons**: words by default, not icons. The one exception is a link to another service (GitHub, a social account), which takes that service's own single-colour glyph in `ink`, 16 to 20px, beside or instead of its name, with an accessible label.
- **Images**: no photographs, stock or illustration, and no AI-generated pictures. The only pictures are the mark, figures made from data, and screenshots of our own tools. Shoggoth is never drawn.
- **Motion**: only colour, background and border change on hover and focus, `0.15s ease`. Nothing slides, fades in on scroll or bounces; respect reduced-motion settings by turning even that off.

## Templates

Each research output has one layout; the components of the same names show them.
- **Research note**: `label` (NOTEBOOK · NO. n), `title`, `lede`, then numbered § sections in `body` at a 38rem measure; figures full measure with numbered captions; references last, in `caption`.
- **Model card**: one per Shoggoth checkpoint. The name and step as the title, then a table of size, tokens seen, data order, seed and links, then what was measured; no adjectives.
- **Slides**: Nocturne, 16:9, one claim per slide as a `title`, the evidence below it, a figure or nothing; the glyph small in a corner, never the full mark.
- **Social card**: 1200 × 630 on `vellum`: `label`, the title in `display`, an italic line in `ink-muted`, a 64px `gilt` rule, the address; the full mark on the right.

## Layout

Square-cut panels (`radius-none`), wide `space-16` margins, `gilt` or `hairline` rules instead of shadows. Ornament is earned: in one view use the ring, a gilt rule, or a run of rubrics, and only one of them. The mark is the exception; it is one object and carries all three.
