# Logos

Every file is generated from one script, so the geometry is identical across them. Each comes in a `-vellum` (light ground, `#faf8f4`) and a `-nocturne` (dark ground, `#14161f`) version; `<img>` cannot inherit colour, so pick by the ground.

- `eisoptric-mark-*.svg`: the full Speculum, transparent. 64px and up. Vellum inks: ink #1f1a14, lapis #23407a, gilt #9c7a2e, vermilion #a8321f. Nocturne inks: #eee6d6, #8fa8e0, #c9a65a, #e07a62.
- `eisoptric-glyph-*.svg`: the mark without its ring and with heavier strokes, transparent. 20–64px.
- `eisoptric-favicon-*.svg`: a 32-pixel redraw on its own ground, for 16 and 32px.
- `eisoptric-icon-*.svg`: 512 square tile with ground, for avatars, app icons and social cards; the mark is centred with 36 units on each side and survives a circular crop.
- `eisoptric-lockup-horizontal-*.svg`, `eisoptric-lockup-stacked-*.svg`: mark with the outlined EISOPTRIC wordmark, transparent.
- PNG exports: icons at 512 and 180, favicons at 32 and 16.
